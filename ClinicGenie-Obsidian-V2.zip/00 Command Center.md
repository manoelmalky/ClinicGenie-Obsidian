# ClinicGenie — Command Center

> **Purpose:** Single source of truth for building ClinicGenie from $0 to first paying clinic.

## North Star
Build a premium AI-powered patient-operations and growth system for dental clinics that captures leads, communicates with patients, automates follow-up, qualifies opportunities, and helps book appointments.

## Current Phase
**Phase 1 — Product foundation + visual system + build**

## Current priorities
- [x] Lock ClinicGenie visual identity
- [x] Lock Command Center screen
- [x] Lock Leads screen
- [x] Build Lead Detail, Conversation, Appointments, and Automations screens
- [ ] Convert approved screens into an implementable product spec (per-screen specs still needed — see Screen Inventory)
- [ ] Reconcile draft Architecture proposal (`04 Engineering/01 Architecture.md`) with Naho's actual plan/repo audit
- [ ] Design remaining screens: Patients, Reports, Settings
- [ ] Build the smallest usable V1
- [ ] Prepare first-clinic sales/demo flow

## Navigate
- [[01 Project/01 Master Plan]]
- [[01 Project/02 V1 Scope]]
- [[02 Product/01 Product Vision]]
- [[02 Product/02 Patient Flow]]
- [[03 UI-UX/01 Visual System]]
- [[03 UI-UX/02 Screen Inventory]]
- [[04 Engineering/01 Architecture]]
- [[05 Team/01 Naho Workstream]]
- [[05 Team/02 Mano Workstream]]
- [[06 Go-To-Market/01 Sales Plan]]
- [[07 Research/01 Market Research]]
- [[08 Decisions/Decision Log]]
- [[09 Prompts/Prompt Library]]
- [[10 Meetings/Meeting Notes]]
- [[11 Tasks/Task Board]]

## Source-of-truth rules
- Obsidian = project/product knowledge
- GitHub = code
- Approved UI references = visual truth
- Major decisions go into the Decision Log


## Operating System
### Product
- [[02 Product/Requirements/00 Requirements Index]]
- [[02 Product/Workflows/01 New Lead Workflow]]
- [[02 Product/Workflows/02 Lead Qualification Workflow]]
- [[02 Product/Workflows/03 Follow-Up Workflow]]
- [[02 Product/Workflows/04 Booking Workflow]]

### UI
- [[03 UI-UX/Screen Specifications/00 Screen Spec Template]]
- [[03 UI-UX/Screen Specifications/Command Center]]
- [[03 UI-UX/Screen Specifications/Leads]]
- [[03 UI-UX/Screen Specifications/Lead Detail]]
- [[03 UI-UX/Screen Specifications/Conversation]]
- [[03 UI-UX/Screen Specifications/Appointments]]
- [[03 UI-UX/Screen Specifications/Automations]]

### Execution
- [[04 Engineering/02 Product-to-Engineering Traceability]]
- [[11 Tasks/Task Template]]
- [[12 Releases/01 V1 Release Plan]]
