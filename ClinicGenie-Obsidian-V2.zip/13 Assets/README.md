# ClinicGenie — Assets

Store or link visual and project assets here.

## Recommended structure
- `UI References/`
- `Brand/`
- `Screenshots/`
- `Architecture/`
- `Sales/`

Large binary assets should generally remain in an appropriate file repository; Obsidian should contain the canonical link and context.
