# ClinicGenie — Visual System

## Brand direction
Premium technology company that happens to specialize in dentistry.

## Established language
- Deep navy typography
- Warm off-white background
- Cool slate secondary text
- Sophisticated teal/mint accent
- Restrained semantic green / blue / amber / red
- Manrope / Inter-like typography
- Subtle borders/shadows
- Calm, precise, premium
- High information density without visual noise

## Approved references
- Command Center
- Leads
- Lead Detail
- Conversation (Messages)
- Appointments
- Automations

All five later screens successfully inherited the Command Center/Leads visual language — no drift observed. See `ClinicGenie UI Design System v1.0` for the full extracted token set (colors, type, spacing, radius, components, Genie visual language, status system).

## Rule
Do not redesign the visual identity per screen. Patients, Reports, and Settings (not yet designed) must inherit this same system rather than starting fresh.
