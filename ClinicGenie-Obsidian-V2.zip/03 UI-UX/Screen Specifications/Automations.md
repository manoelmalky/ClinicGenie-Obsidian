# Screen Specification — Automations

## Status
**Approved visual reference**

## Purpose
Allow clinic users to understand and manage automated operational workflows.

## Requirements
Each automation shows:
- Trigger
- Conditions
- Action
- Timing
- Enabled/disabled state
- Recent activity
- Failure/error state

## Primary action
Create, inspect, enable/disable, or modify an automation.

## Related
- [[02 Product/Requirements/05 Automations]]
