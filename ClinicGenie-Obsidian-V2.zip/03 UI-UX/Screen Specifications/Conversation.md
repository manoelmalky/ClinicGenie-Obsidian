# Screen Specification — Conversation

## Status
**Approved visual reference**

## Purpose
Provide a focused patient communication workspace with full context.

## Requirements
- Conversation history
- Patient/lead context
- Clear reply action
- AI assistance
- Follow-up context
- Appointment context

## Rule
AI assistance must preserve the established ClinicGenie tone and never fabricate clinic facts.
