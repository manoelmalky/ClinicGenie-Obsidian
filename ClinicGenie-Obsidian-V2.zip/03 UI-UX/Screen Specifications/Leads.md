# Screen Specification — Leads

## Status
**Approved visual reference**

## Purpose
Provide an organized workspace for managing opportunities.

## Primary actions
- Search/filter
- Open lead
- Update status
- Take next action

## Must communicate
- Patient identity
- Lifecycle status
- Treatment intent
- Lead source
- Follow-up state
- Relevant timing

## Related
- [[02 Product/Requirements/01 Lead Management]]
