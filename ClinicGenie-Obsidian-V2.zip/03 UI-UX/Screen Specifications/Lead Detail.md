# Screen Specification — Lead Detail

## Status
**Approved visual reference**

## Purpose
Provide the complete workspace for understanding and acting on one lead.

## Must communicate
- Patient context
- Lead status
- Treatment intent
- Conversation/history
- Follow-up
- Appointment state
- Recommended next action

## Primary action
Move the lead toward the appropriate next step, especially qualified booking.

## AI behavior
Genie can summarize context and recommend actions, but must use authoritative data.

## Related
- [[02 Product/Requirements/01 Lead Management]]
- [[02 Product/Requirements/03 Follow-Up]]
- [[02 Product/Workflows/02 Lead Qualification Workflow]]
