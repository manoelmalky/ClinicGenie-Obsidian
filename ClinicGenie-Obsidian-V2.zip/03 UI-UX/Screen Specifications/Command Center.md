# Screen Specification — Command Center

## Status
**Approved visual reference**

## Purpose
Give clinic staff an immediate view of what needs attention and how the clinic is performing.

## Primary action
Act on the highest-value operational items.

## Must communicate
- Lead volume and status
- Follow-up requiring attention
- Appointment activity
- Important trends
- High-priority opportunities
- Clear next actions

## Visual rule
Follow [[03 UI-UX/01 Visual System]] and [[03 UI-UX/UI Design System v1.0]] exactly.

## Acceptance criteria
A clinic user should understand what requires attention within seconds.
