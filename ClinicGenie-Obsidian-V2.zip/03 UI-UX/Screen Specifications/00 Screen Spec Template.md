# Screen Specification — Template

## Purpose

## Primary user

## Business problem

## Primary action

## Secondary actions

## Layout

## Components

## Data

## Interactions

## AI / Genie behavior

## States
- Empty
- Loading
- Error
- Success
- Disabled

## Responsive behavior

## Accessibility

## Engineering notes

## Acceptance criteria

## Related
- Product requirement:
- Design system:
- GitHub:
