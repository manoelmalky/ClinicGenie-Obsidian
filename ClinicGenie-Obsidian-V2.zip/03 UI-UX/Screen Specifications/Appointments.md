# Screen Specification — Appointments

## Status
**Approved visual reference**

## Purpose
Provide a clear view of booking activity and appointment state.

## Requirements
- Upcoming appointments
- Booking state
- Patient context
- Lead relationship
- Relevant actions
- Clear appointment status

## Rule
Availability must come from an authoritative source.
