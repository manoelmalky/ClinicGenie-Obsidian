# ClinicGenie — Screen Inventory

| Screen | Status | Purpose |
|---|---|---|
| Command Center | Approved | Operational overview, Genie insights, quick actions |
| Leads | Approved | Lead management, filtering, bulk actions |
| Lead Detail | Approved | Full lead workspace — status, conversation, follow-up timeline |
| Conversation (Messages) | Approved | Patient communication, Genie-assisted replies, human handoff |
| Appointments | Approved | Calendar/list booking management, requests, confirmations |
| Automations | Approved | Trigger/condition/action workflows, follow-up sequences |
| Patients | Not yet specified | Patient records distinct from active leads — exists in nav, no spec |
| Reports | Not yet specified | Performance visibility (nav item is "Reports," not "Analytics" — reconcile naming) |
| Settings | Planned | Clinic configuration |
| AI / Command | Implicit — not a standalone screen | "Ask Genie" is embedded per-screen rather than a separate surface; confirm this is intentional and not a missing screen |

## Naming note
Product nav uses "Messages" and "Automation" (singular); this vault and prior docs used "Conversations" and "Automations" (plural). Pick one vocabulary and use it consistently across vault, specs, and code.

## Every screen specification must include
- Purpose
- Primary user
- Primary action
- Secondary actions
- Data
- States
- Empty/loading/error behavior
- Responsive behavior
- AI actions

## Still needed
- Patients screen spec (how it differs from Leads — likely: Leads = pre-conversion pipeline, Patients = converted/booked history)
- Reports screen spec
- Settings screen spec
- Confirm whether a standalone AI/Command surface is planned or if per-screen "Ask Genie" is the permanent pattern
