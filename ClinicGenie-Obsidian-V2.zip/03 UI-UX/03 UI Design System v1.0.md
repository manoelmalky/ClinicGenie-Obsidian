# ClinicGenie UI Design System v1.0

*Reverse-engineered from the approved Command Center, Leads, Lead Detail, Conversation, Appointments, and Automations screens. This is a documentation of what exists, not a redesign.*

---

## 1. Design Principles

1. **Every screen answers two questions:** *What does the clinic need to know?* and *What can the clinic do next?* — visible in the consistent pairing of a stat/status row with an immediate action row (e.g., Appointments: "4 awaiting approval" → Confirm/Reject buttons right there).
2. **Information before decoration.** Layouts are data-dense but ungarnished — no illustrations, no gradients, no marketing flourishes inside the product.
3. **Genie provides intelligence *and* action, not just analytics.** Every Genie Insight card ships with at least one actionable CTA (Follow Up, Review requests, Ask Genie) — never a stat with nowhere to go.
4. **Important actions are visually obvious.** Primary actions are always the single dark-teal filled button on a row; everything else is outlined or text-level.
5. **AI is recognizable but never overwhelming.** The sparkle (✦) and mint tinting mark Genie's presence consistently, but only on Genie-originated content — not applied decoratively to the whole UI.
6. **Human intervention is always one click away.** "Take over conversation," "Human Needed" badges, and "Ask Genie" secondary buttons sit right next to Genie's own actions.
7. **Calm under complexity.** Even the Automation builder (5-step logic chains) is rendered as a flat, evenly spaced step tracker rather than a dense flowchart.
8. **Operational state is scannable in under 5 seconds.** Top-of-page stat cards (counts + vs.-last-period deltas) appear identically on Leads, Appointments, and Automations.
9. **Color is used sparingly and semantically.** Neutral navy/slate/white dominates; color appears only on status, semantic feedback, and Genie surfaces.
10. **No vanity dashboards.** No pie charts, gauges, or heavy visualization — state is communicated via counts, badges, and short insight sentences.

---

## 2. Color Tokens

### Brand
| Name | Role | Approx. HEX | Usage rule |
|---|---|---|---|
| Primary | Deep navy | `#0F172A` | Headings, primary text, logo wordmark, active icons |
| Secondary | Slate gray | `#64748B` | Secondary text, muted labels, inactive nav icons |
| Accent | Teal/mint | `#0D9488` (button-strength) / `#14B8A6` (bright) | Primary buttons, active nav state, links, Genie sparkle |

### Surface
| Name | Role | Approx. HEX | Usage rule |
|---|---|---|---|
| Background | App canvas | `#FAFAF8` | Page background behind all cards |
| Card | Container surface | `#FFFFFF` | Cards, tables, modals, side panels |
| Elevated | Raised surface | `#FFFFFF` w/ shadow-sm | Dropdowns, popovers, selected-appointment panel |
| Border | Divider/outline | `#E5E7EB` | Card borders, table row dividers, input outlines |

### Text
| Name | Role | Approx. HEX | Usage rule |
|---|---|---|---|
| Primary | Headings, names, key values | `#0F172A` | Page titles, patient names, stat numbers |
| Secondary | Supporting copy | `#475569` | Descriptions, message bodies |
| Muted | Metadata | `#94A3B8` | Timestamps, "vs last week," helper text |
| Disabled | Inactive text | `#CBD5E1` | Disabled inputs, placeholder text |

### Semantic
| Name | Role | Approx. HEX | Usage rule |
|---|---|---|---|
| Success | Confirmed / positive | `#16A34A` (text) / `#DCFCE7` (fill) | Confirmed, Booked, Active, High Potential badges |
| Info | Neutral progress state | `#2563EB` (text) / `#DBEAFE` (fill) | Contacted, Interested, Rescheduled badges |
| Warning | Needs action, pending | `#D97706` (text) / `#FEF3C7` (fill) | Pending, Warm, Paused, Human Needed badges |
| Error | Negative / stalled | `#DC2626` (text) / `#FEE2E2` (fill) | Cancelled, No Response, Needs Attention badges |

### AI / Genie
| Name | Role | Approx. HEX | Usage rule |
|---|---|---|---|
| Genie primary | Sparkle + Genie CTA fill | `#0D9488` | Sparkle icon, "Ask Genie" filled buttons |
| Genie surface | Insight card background | `#F0FDFA` | Genie Insight / Recommendation card fills |
| Genie highlight | Border/glow accent | `#99F6E4` | Genie card borders, subtle highlight rings |

---

## 3. Typography Tokens

- **Brand/display font:** Manrope-like — used only for the ClinicGenie logotype and marketing surfaces.
- **Primary UI font:** Inter-like — used for everything inside the product.

| Token | Size | Weight | Line-height | Usage |
|---|---|---|---|---|
| Page title | 28–30px | Bold (700) | 1.2 | "Leads," "Appointments," "Automations" |
| Section heading | 16–18px | Semibold (600) | 1.3 | "Your Automations," "Patient Summary" |
| Card stat number | 24–28px | Bold (700) | 1.2 | Stat card counts (8, 146, 24) |
| Body | 14px | Regular (400) | 1.5 | Message text, descriptions |
| Label / table header | 12–13px | Medium (500), uppercase or capitalized | 1.4 | Table column headers, form labels |
| Metadata | 12px | Regular (400) | 1.4 | Timestamps, "2h ago," deltas |
| Button text | 14px | Medium/Semibold (500–600) | 1.2 | All button labels |
| Badge text | 11–12px | Medium (500), uppercase or title case | 1.2 | Status pills |
| Helper text | 12–13px | Regular (400) | 1.4 | Input hints, empty-state subtext |

---

## 4. Spacing Tokens

| Token | Value | Usage |
|---|---|---|
| xs | 4px | Icon-to-label gap, badge internal padding |
| sm | 8px | Between inline elements (icon + text), tight stack gaps |
| md | 12px | Table cell padding, compact card internal padding |
| base | 16px | Standard card padding, gap between stat cards |
| lg | 20px | Section internal padding |
| xl | 24px | Gap between major page sections, card-to-card gutters |
| 2xl | 32px | Page margin from sidebar/top bar |
| 3xl | 40px | Vertical rhythm between major page zones |
| 4xl | 48px | Rarely used — large empty-state vertical spacing |
| 5xl | 64px | Top-level page padding on wide layouts |

---

## 5. Radius Tokens

| Element | Radius |
|---|---|
| Card | 12px |
| Button | 8px |
| Input | 8px |
| Badge | Full (pill, 9999px) |
| Avatar | Full (circle) |
| Modal | 16px |

---

## 6. Border & Shadow Tokens

**Borders:** 1px solid, color `#E5E7EB` (Surface/Border token). Used to separate cards from the off-white background, delineate table rows, and outline inputs. Never used decoratively or at heavier weights.

**Shadows — kept deliberately restrained:**
- `none` — default state for most cards on the off-white background (the border alone does the separating).
- `subtle` — `0 1px 2px rgba(15,23,42,0.04)` — used on interactive cards on hover and dropdown/popover surfaces.
- `elevated` — `0 4px 12px rgba(15,23,42,0.08)` — reserved for modals and the floating "Selected Appointment" panel.

---

## 7. Iconography

- **Style:** Outline/stroke icons (not filled), consistent 1.5–2px stroke weight.
- **Size hierarchy:** 16px inline with text/labels, 20px in nav and buttons, 24px for card header icons.
- **Alignment:** Icons are vertically centered with their adjacent label text, left-aligned before text in nav items and buttons.
- **Semantic icon behavior:** Icons reinforce status color (a check-circle in green for Confirmed, a clock in amber for Pending, an alert-triangle in red for Needs Attention) — color is never used alone.
- **The Genie sparkle (✦)** is the one icon exempt from the outline system — see Section 9.

---

## 8. Component Specifications

### Buttons
- **Primary:** Solid dark teal fill (`Accent`), white text, 8px radius. One per view/row — reserved for the single most important action (Create Automation, Add Appointment, Follow Up, Confirm).
- **Secondary:** White fill, 1px slate border, navy text. Used for lower-priority or alternate actions sitting beside a Primary button (Ask Genie, Reject, Reschedule).
- **Tertiary/text:** No fill, no border, teal or navy text only. Used for low-emphasis links like "View all," "View details."
- **Destructive:** Same shape as Secondary but red text/border, or solid red fill for high-stakes destructive actions (Reject, Cancel).

### Inputs
- **Text:** White fill, 1px slate border, 8px radius, muted placeholder text.
- **Search:** Same as text input with leading search icon; used at the top of list views (Leads, Appointments).
- **Select/Filter:** Bordered control with trailing chevron; filter bars use a row of these side-by-side (Date, Doctor, Treatment, Status).
- **Date:** Calendar-icon-prefixed input, opens a calendar picker matching the Appointments calendar grid.
- **Command/Ask Genie input:** Visually distinct — rounded field with the Genie sparkle icon and placeholder like "Ask Genie…" or "What would you like to automate?"; paired with a filled circular send button.

### Navigation
- **Sidebar:** Fixed left rail, icon + label rows, navy text/icons at rest.
- **Selected state:** Light mint/teal background fill behind the row, teal text and icon.
- **Hover state:** Very light gray background fill, no color change to icon/text.
- **Notification:** Small red dot on the bell icon in the top bar — count not shown, presence only.

### Cards
- **Standard:** White fill, 1px border, 12px radius, base(16px) padding — used for generic content grouping.
- **Insight (Genie Insight):** Genie-surface mint fill, teal-tinted border, sparkle icon in header — always paired with 1–2 CTA buttons.
- **Recommendation:** Same treatment as Insight cards; used specifically for "Recommended next action" content within Lead Detail and sidebars.
- **Action card:** Standard white card whose primary content is a button (e.g., "Create Automation" step card).
- **Data/stat card:** Compact white card showing an icon, label, large number, and a small delta line ("↑ 2 vs last week").

### Badges
All badges are pill-shaped (full radius), colored per the Semantic tokens, with a small leading dot or icon:
- **New** — neutral gray
- **Interested** — info blue
- **High Potential** — success green
- **Warm** — warning amber
- **No Response** — error red
- **Human Needed** — warning amber (with alert icon)
- **Booked** — success green
- **Confirmed** — success green
- **Pending** — warning amber
- **Cancelled** — error red
- **Rescheduled** — info blue

### Tables
- **Header:** Muted-text, small caps or medium-weight labels, bottom border, no fill.
- **Row:** White background, 1px bottom border, base vertical padding.
- **Selected row:** Light teal-tinted background fill with a visible checkbox checked.
- **Hover:** Very light gray row fill.
- **Empty:** Centered icon + one-line message + a single primary action (e.g., "No appointments scheduled" → Add Appointment).
- **Loading:** Left-aligned spinner icon + "Loading…" muted text in the row/footer position.

### Conversation
- **Patient message:** Left-aligned, white/light-gray bubble, avatar at left.
- **Genie message:** Right-aligned (as the acting party), mint-tinted bubble with sparkle mark.
- **Human message:** Right-aligned, same position as Genie but without the sparkle — visually near-identical to Genie except for the icon/label, so the sparkle is the only differentiator.
- **System event:** Full-width, no-bubble, centered or left-aligned muted text row (e.g., "Follow-up scheduled," "Patient has not responded") often in a tinted strip matching its semantic color (amber for waiting, teal for scheduled).
- **Composer:** Bottom-fixed bar with attachment icon, text input, a distinct "Ask Genie" chip button, and a circular teal send button.
- **Genie suggestion:** Inline chip above the composer (e.g., "Ask Genie — What should I say?") — low-commitment, one tap to expand.

### Appointments
- **Appointment card (calendar block):** Colored left border or fill tint matching status (green=Confirmed, amber=Pending, red=Cancelled, blue=Rescheduled), patient name bold, treatment + provider as secondary text.
- **Request:** Distinct list-item card (not on the calendar) with Confirm (primary) / Reject (secondary) buttons.
- **Booked by Genie:** Same card styling as any other confirmed appointment, plus a small teal "Booked by Genie" tag — status and origin are kept visually separate.

### Automations
- **Trigger / Condition / Action / Schedule / Stop Condition:** Rendered as numbered circular step badges (1–5) connected by thin arrows — identical treatment whether in the builder preview or the "Create Automation in 5 steps" card.
- **Active:** Green badge.
- **Paused:** Slate/gray badge.
- **Needs attention:** Red badge with alert icon.

---

## 9. Genie Visual Language

**Shape:** A four-pointed sparkle/diamond ("✦"), used as both the product's logo mark and the recurring AI indicator.

**Color:** Always teal/mint (Genie primary `#0D9488` or brighter accent) — never navy, never a semantic color.

**Size:** Small (12–16px) inline next to text/labels; slightly larger (20–24px) as a standalone header icon on Genie cards; large only in the wordmark logo.

**Placement:** Immediately to the left of any text that is Genie-authored, Genie-recommended, or Genie-classified — in message bubbles, insight card headers, "Ask Genie" buttons, badges like "Genie-powered," and next to Genie-assigned owner fields in tables.

**When it appears:**
- Genie sends a message or classification in a conversation.
- A card contains an AI-generated insight or recommendation.
- An action was performed automatically by Genie (booked appointment, sent follow-up).
- A button initiates a Genie action ("Ask Genie," "Follow Up" when Genie-suggested).

**When it should NOT appear:**
- On human-authored messages or manually-performed actions.
- As a purely decorative flourish on unrelated navigation, static labels, or non-AI content.
- Repeated multiple times within a single card/message purely for emphasis.

Genie should read as **intelligence + action** — every sparkle-marked element pairs a short insight sentence with a concrete next-step button, not a raw statistic.

---

## 10. Status System

These four systems are visually distinct and must never share a badge style or be merged into one field.

**Lead Lifecycle** *(where the deal is in the pipeline)*
New → Contacted → Qualified → Booked → Completed / Lost / Unqualified
- Rendered as a horizontal progress tracker with checkmarked circles (Lead Detail page).

**Lead Intent** *(how engaged/likely-to-convert the patient is)*
New · Interested · High Potential · Warm · No Response · Human Needed
- Rendered as a standalone colored pill, always shown adjacent to — never merged with — the Lifecycle tracker.

**Appointment Status**
Pending · Confirmed · Cancelled · Rescheduled · Completed
- Rendered as colored pills on calendar blocks and list rows.

**Automation Status**
Active · Paused · Running · Completed · Needs Attention
- Rendered as colored pills in the automation table and summary stat cards.

---

## 11. UX Patterns (Genie Patterns)

| Pattern | Visual treatment | Hierarchy | When to use | Primary CTA | Secondary CTA |
|---|---|---|---|---|---|
| **Ask Genie** | Sparkle-prefixed input field or chip | Low-commitment, always available | Free-form question entry point | Send (circular icon button) | — |
| **Genie Insight** | Mint card, sparkle header, one sentence | Top-of-page, high visibility | Surfacing a pattern across many records | Review/primary action | Ask Genie |
| **Genie Recommendation** | Mint card, sparkle header, bolded recommended action | Prominent, near page title | Single-record next-best-action | Take the action (e.g., Follow Up) | Ask Genie |
| **Next Action** | Compact text block, no full card | Medium | Per-record shorthand in list/detail views | Contextual verb button (Send follow-up, Call patient) | — |
| **Genie Action** | List of chip/expandable rows | Medium, secondary panel | Menu of things Genie can do on this record | Tap to execute | — |
| **Genie-powered** | Small tag/label only | Lowest, metadata-level | Marking an automation or message as AI-originated | — | — |
| **Human handoff** | "Take over conversation" button + amber/neutral marker | Always visible, never hidden | Any time a human may need to intervene | Take over | — |

---

## 12. Accessibility

- **Text contrast:** Primary navy text on off-white/white background exceeds 7:1; muted metadata text is kept ≥4.5:1 against its background.
- **Focus states:** Visible focus ring (teal, 2px) on all interactive elements — buttons, inputs, table rows, nav items.
- **Keyboard navigation:** All primary actions (Confirm/Reject, Follow Up, Ask Genie) must be reachable and triggerable via keyboard/tab order matching visual left-to-right, top-to-bottom flow.
- **Status = color + text/icon:** Every status badge pairs its color with a text label and/or icon (never a bare colored dot) so status is legible without color perception.
- **Minimum interactive target size:** 40x40px minimum for buttons and icon-only controls.
- **Readable typography:** Body text minimum 14px; no UI text below 12px.

---

## 13. Responsive Behavior

*Rules to preserve hierarchy — not a mobile redesign.*

- **Desktop (primary target):** Full three-zone layout — sidebar, main content, right-hand Genie/context panel — as shown in all approved screens.
- **Tablet:** Right-hand Genie/context panel collapses into a toggled drawer or moves below the main content; sidebar may collapse to icon-only; stat card rows wrap to 2–3 per row instead of scrolling horizontally.
- **Mobile:** Sidebar becomes a bottom nav or hamburger drawer; stat cards stack to a horizontal scroll or single column; tables convert to stacked record cards preserving the same badge/label hierarchy; the Genie Insight card always remains above the fold since it carries the primary "what's next" signal.
- **Preserved across all breakpoints:** page title + one-line description at top; Genie Insight/Recommendation always visible before the user must scroll to secondary content; primary action button never demoted below secondary actions.

---

## 14. Do / Don't

**Do**
- Pair every Genie insight with a concrete action button.
- Keep one Primary (filled) button per view or row.
- Use the sparkle only on Genie-originated content.
- Show Lifecycle and Intent as two separate, adjacent elements.
- Use color only for semantic status, never for emphasis or decoration.

**Don't**
- Don't add charts, gauges, or dashboards beyond simple stat cards.
- Don't apply the Genie sparkle to human actions or static navigation.
- Don't merge lifecycle stage and intent into a single badge or field.
- Don't introduce a second accent color alongside teal/mint.
- Don't use shadows beyond the three defined levels (none/subtle/elevated).
