# ClinicGenie V1 — Release Plan

## Release goal
A real clinic can take a lead from capture through communication and booking while seeing the complete operational state.

## Release gates

### Product
- [ ] V1 requirements complete
- [ ] Core workflows validated

### Design
- [ ] Approved screens implemented consistently
- [ ] States covered
- [ ] Responsive behavior covered

### Engineering
- [ ] Auth
- [ ] Data isolation
- [ ] Lead flow
- [ ] Conversation flow
- [ ] Follow-up
- [ ] Appointment flow
- [ ] AI behavior
- [ ] Logging
- [ ] Deployment

### Demo
- [ ] Demo data
- [ ] Demo script
- [ ] ROI narrative

### Commercial
- [ ] Prospect list
- [ ] Outreach
- [ ] Pilot offer
