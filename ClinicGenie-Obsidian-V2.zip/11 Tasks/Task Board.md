# ClinicGenie — Task Board

## 🔴 NOW
- [ ] Finalize Lead Detail UI
- [ ] Consolidate approved UI references
- [ ] Import Naho architecture plan
- [ ] Convert architecture into V1 implementation checklist

## 🟡 NEXT
- [ ] Complete screen inventory
- [ ] Define core data model
- [ ] Define AI action model
- [ ] Define appointment workflow
- [ ] Build demo data

## 🟢 LATER
- [ ] Advanced automation
- [ ] Additional integrations
- [ ] Advanced analytics

## Task format
- [ ] **Task** — owner — priority — dependency
