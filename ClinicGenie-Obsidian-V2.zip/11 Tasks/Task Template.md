# Task Template

## Task
**Owner:** Mano / Naho  
**Area:** Product / Design / Engineering / GTM  
**Priority:** P0 / P1 / P2  
**Status:** Backlog / Ready / In Progress / Review / Done  
**Dependency:**  
**Product requirement:**  
**UI reference:**  
**GitHub issue/PR:**  

## Objective

## Acceptance criteria
- [ ] 
- [ ] 
- [ ] 

## Notes

## Decision link
