# ClinicGenie — Prompt Library

## Categories
- UI generation
- UI refinement
- Product specification
- Architecture
- Coding
- AI behavior
- Patient conversation
- Sales
- Research

## Template
### Prompt name
**Purpose:**  
**When to use:**  
**Inputs:**  
**Prompt:**  
**Expected output:**  
**Notes:**

## Rule
Store useful, repeatable prompts rather than every experiment.
