# ClinicGenie — Market Research

## Initial treatment categories
- Implants
- Veneers
- Crowns
- Dentures
- Whitening / cleaning

## Market
USA, with emphasis on high-end dental clinics.

## Research questions
- Which treatments have high economic value?
- Which generate meaningful lead volume?
- Which have long consideration cycles?
- Where does follow-up failure cost clinics the most?
- Which clinic types are easiest to reach?
- What software do they already use?
- What is the current AI/automation landscape?
- What makes clinics pay?

## Rule
Research should change product, positioning, pricing, or sales decisions.
