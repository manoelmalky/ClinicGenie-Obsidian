# ClinicGenie — Sales Plan

## Initial market
United States.

## Target
High-value dental clinics and groups where lead volume and treatment value justify ClinicGenie.

## Value story
ClinicGenie helps clinics recover and convert opportunities that would otherwise disappear through slow or inconsistent follow-up.

## Demo story
New lead → qualification → intelligent follow-up → appointment → clinic visibility.

## First sales assets
- Demo
- One-page explanation
- ROI story
- Outreach script
- Discovery questions
- Objection handling
- Pilot offer
