# Workflow — Booking

1. Determine whether the patient wants to book.
2. Retrieve authoritative availability.
3. Present appropriate slots.
4. Patient/clinic selects slot.
5. Confirm booking.
6. Associate appointment with patient and lead.
7. Update lead state.
8. Schedule relevant follow-up/reminders.
