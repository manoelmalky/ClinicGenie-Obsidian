# Workflow — New Lead

**Trigger:** New lead enters ClinicGenie.

1. Capture lead data.
2. Normalize and store information.
3. Identify source.
4. Assign lifecycle state.
5. Identify known treatment intent.
6. Determine next action.
7. Start conversation/follow-up according to clinic rules.
8. Surface the lead in the Command Center.
9. Track outcome.

## Success
Lead becomes a qualified conversation or booked appointment rather than disappearing.
