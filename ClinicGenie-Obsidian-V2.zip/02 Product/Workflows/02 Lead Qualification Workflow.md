# Workflow — Lead Qualification

1. Read available lead context.
2. Determine what the patient is trying to achieve.
3. Ask only useful open-ended questions.
4. Identify treatment intent when possible.
5. Handle direct requests efficiently.
6. Answer only from authoritative clinic information.
7. Determine whether booking is appropriate.
8. Offer available appointment options when authorized.
9. Record qualification context.
