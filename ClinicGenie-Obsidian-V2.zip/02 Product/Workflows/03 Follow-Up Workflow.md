# Workflow — Follow-Up

1. Identify lead whose follow-up condition is met.
2. Check lifecycle/status and previous contact.
3. Check clinic automation rules.
4. Generate or select the appropriate follow-up action.
5. Send automatically or request staff approval according to policy.
6. Record action and result.
7. Update next follow-up state.
8. Escalate to staff when needed.
