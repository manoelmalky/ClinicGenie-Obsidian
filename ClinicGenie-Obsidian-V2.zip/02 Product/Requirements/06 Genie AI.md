# Requirement — Genie AI

## Purpose
Provide a simple natural-language interface for clinic operations.

## Genie should
- Understand clinic context.
- Answer from authoritative clinic data.
- Recommend actions.
- Execute approved actions.
- Explain what it did.
- Ask for clarification when required.

## Genie must not
- Invent data.
- Invent availability.
- Invent prices.
- Make unsupported clinical claims.
- Perform destructive actions without appropriate confirmation.

## Example
“Show me the leads that need follow-up today.”

→ identify matching leads
→ explain why they qualify
→ present recommended actions
→ allow the clinic to execute approved actions.
