# Requirement — Follow-Up

## Goal
Prevent valuable leads from being lost because follow-up is late or inconsistent.

## Core behavior
- Detect when follow-up is due.
- Respect clinic-defined rules.
- Surface recommended next action.
- Record sent/attempted follow-ups.
- Allow staff approval where required.
- Support automation only when explicitly enabled.

## Acceptance criteria
A clinic can see which leads need follow-up and why.
