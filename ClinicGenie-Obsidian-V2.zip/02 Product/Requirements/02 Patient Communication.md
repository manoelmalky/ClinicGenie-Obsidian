# Requirement — Patient Communication

## Goal
Give clinics a clear, context-aware communication workspace.

## Core behavior
- Preserve conversation history.
- Show patient context.
- Allow clinic staff to respond.
- Allow approved AI assistance.
- Keep communication tied to the lead record.
- Never fabricate clinical, pricing, availability, or policy information.

## Acceptance criteria
A staff member can understand the conversation without leaving the lead workspace.
