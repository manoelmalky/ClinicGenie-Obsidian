# Requirement — Lead Management

## Problem
Clinics need a reliable way to capture, organize, understand, prioritize, and act on patient opportunities.

## Core behavior
A lead must have:
- Identity/contact information
- Source
- Lifecycle status
- Treatment intent
- Conversation history
- Follow-up history
- Appointment state
- Ownership/assignment
- Relevant notes

## Acceptance criteria
- A new lead can be created.
- Staff can find and filter leads.
- Staff can understand the lead's current state.
- Staff can open a complete lead workspace.
- Every major lead action is traceable.

## Related
- [[02 Product/02 Patient Flow]]
- [[03 UI-UX/Screen Specifications/Lead Detail]]
- [[03 UI-UX/Screen Specifications/Leads]]
