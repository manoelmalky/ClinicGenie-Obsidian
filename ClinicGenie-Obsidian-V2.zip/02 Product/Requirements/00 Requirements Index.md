# Product Requirements — Index

ClinicGenie's product requirements are the contract between product vision and engineering implementation.

## Requirements
- [[01 Lead Management]]
- [[02 Patient Communication]]
- [[03 Follow-Up]]
- [[04 Appointments]]
- [[05 Automations]]
- [[06 Genie AI]]

## Requirement template
Every requirement should define:
- Problem
- User
- Desired outcome
- Functional behavior
- Business rules
- AI behavior, if applicable
- Edge cases
- Acceptance criteria
- Related UI
- Related engineering work
