# Requirement — Automations

## Goal
Allow clinics to automate repeatable patient-operation workflows.

## Initial examples
- Follow up with a lead after a defined period.
- Remind a lead about an unfinished booking.
- Notify staff when a high-priority lead needs attention.
- Trigger internal actions based on lead status.

## Automation requirements
Every automation needs:
- Trigger
- Conditions
- Action
- Timing
- Owner
- Enabled/disabled state
- Audit history
- Failure behavior

## Safety
Automation must respect clinic configuration and approval rules.
