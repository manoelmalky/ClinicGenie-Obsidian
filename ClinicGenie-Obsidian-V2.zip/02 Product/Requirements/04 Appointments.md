# Requirement — Appointments

## Goal
Turn qualified patient conversations into organized appointments.

## Core behavior
- Show available slots from an authoritative source.
- Allow the patient/clinic to select a slot.
- Record booking status.
- Associate appointment with the lead/patient.
- Surface upcoming and missed/cancelled appointments.

## Rule
ClinicGenie must not invent availability.
