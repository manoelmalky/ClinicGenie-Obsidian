# ClinicGenie — Patient Flow

## Target flow
Ad/referral
→ patient submits information
→ ClinicGenie captures lead
→ lead is organized
→ AI/clinic communicates
→ needs and treatment intent are understood
→ available slots are surfaced
→ appointment is booked
→ follow-up continues
→ clinic sees outcome

## Conversation principles
- Simple
- Direct
- Human
- Context-aware
- Sales-aware without being pushy
- Ask open-ended discovery questions when needed
- Handle direct slot requests efficiently
- Handle treatment/price questions accurately
- Never invent clinical or pricing information

## Primary conversion event
**Booked qualified appointment**
