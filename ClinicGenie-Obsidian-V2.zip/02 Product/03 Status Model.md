# ClinicGenie — Status Model

> Extracted from the approved screens. This model exists and is implemented visually, but was previously undocumented at the product level — engineering had nothing but the UI to infer it from. Written down here so it doesn't get flattened into a single `status` field.

## Rule
**Lifecycle and Intent are two separate fields on a lead. They are never merged, never shown as one badge, and never treated as one column in the data model.**

## Lead Lifecycle
*Where the opportunity sits in the pipeline. Progresses roughly in order.*

`New → Contacted → Qualified → Booked → Completed`
(exit states: `Lost`, `Unqualified`)

- Owned by the pipeline stage — set by clinic action or Genie action (e.g., booking an appointment moves a lead to Booked).
- Rendered as a horizontal progress tracker on Lead Detail.

## Lead Intent
*How engaged/likely-to-convert the patient currently seems. Not ordered — can move in any direction, can change independent of lifecycle.*

`New · Interested · High Potential · Warm · No Response · Human Needed`

- Set by Genie's read of the conversation (engagement signals, questions asked, responsiveness).
- Drives Genie's recommended next action (e.g., "High Potential" + no follow-up in 72h → recommend Follow Up).
- A lead can be `Contacted` (lifecycle) and `No Response` (intent) at the same time — that combination is in fact the primary trigger for the "No Response — Initial Follow-up" automation.

## Appointment Status
`Pending → Confirmed` (or `Cancelled` / `Rescheduled` from either state) `→ Completed`

- Independent of lead lifecycle/intent — an appointment can be Confirmed while the underlying lead is still Contacted, not yet Booked (booking the appointment is likely what flips lifecycle to Booked — **needs a decision**: does appointment=Confirmed trigger lifecycle=Booked automatically, or is that a separate clinic/Genie action?).
- `Booked by Genie` is an **origin tag**, not a status — it can co-exist with any of the above and should not be confused with Confirmed.

## Automation Status
`Active / Paused` (configuration state) — independent of a given run's outcome:
`Running → Completed` or `Needs Attention` (per-execution state)

An automation is built from five ordered components, always in this order:
1. **Trigger** — the event that starts it (e.g., "Lead enters No Response")
2. **Condition** — optional filter (e.g., "Appointment = Not Booked")
3. **Action** — what Genie does (e.g., "Send personalized follow-up")
4. **Schedule** — timing/delay (e.g., "After 3 days")
5. **Stop Condition** — what ends the sequence early (e.g., "Patient responds OR Appointment booked OR Human takes over")

**Open question, needs a decision:** the UI shows "Mass messaging requires approval before execution" as a stop-condition-adjacent note — is there a broader class of Genie actions that require human approval before executing (vs. fully autonomous actions)? This distinction (autonomous vs. approval-required Genie actions) isn't defined anywhere yet and has real implications for the AI action model in Phase 1.

## Open items for Phase 1 (Define AI responsibilities/boundaries, Define data model)
- [ ] Decide whether Appointment Confirmed auto-advances Lead Lifecycle to Booked, or if that's a separate step
- [ ] Define the full set of Intent values as an enum (confirm the six above are exhaustive for V1)
- [ ] Define which Genie actions are autonomous vs. require clinic approval before sending/executing
- [ ] Confirm "Patients" (nav item, no spec yet) = leads that have reached Booked/Completed, or a genuinely separate record type
