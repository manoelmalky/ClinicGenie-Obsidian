# ClinicGenie — V1 Scope

## Core loop
**Capture → Organize → Understand → Follow up → Book → Track**

## Must have
- Lead capture
- Leads list
- Lead detail
- Lead status/lifecycle
- Patient information
- Conversation/history
- Follow-up workflow
- Appointment availability
- Booking workflow
- Command Center
- Basic analytics
- AI assistant/action interface
- Authentication and clinic separation

## Later
- Advanced marketing automation
- Additional channels
- Deep CRM integrations
- Advanced reporting
- Multi-location enterprise controls

## Non-goals
ClinicGenie should not become a generic CRM or generic chatbot.

## Acceptance test
A clinic can take a new lead from initial capture to booked appointment and see what happened at every stage.
