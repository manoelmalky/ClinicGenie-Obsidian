# ClinicGenie — Master Plan

## Objective
Go from concept → working V1 → demo → first paying dental clinic while keeping tooling/infrastructure as close to $0 as practical.

## Phase 0 — Foundation
- [x] Core concept defined
- [x] Mano / Naho responsibilities defined
- [x] Visual identity direction established
- [x] Obsidian adopted as project knowledge base

## Phase 1 — Product Definition
- [ ] Finalize V1 scope
- [ ] Define clinic workflow
- [ ] Define patient workflow
- [ ] Define lead lifecycle
- [ ] Define appointment workflow
- [ ] Define AI responsibilities/boundaries
- [ ] Define data model
- [ ] Define required integrations

## Phase 2 — UI/UX
- [x] Command Center direction
- [x] Leads direction
- [x] Lead Detail
- [x] Conversation (Messages)
- [x] Appointments
- [x] Automations
- [ ] Patients
- [ ] Reports
- [ ] Settings
- [ ] Confirm AI/Command interface pattern (currently embedded per-screen, not standalone)
- [ ] Empty/loading/error states — designed within existing screens (see Appointments empty state) but not yet specified per-screen
- [ ] Responsive behavior — rules drafted in UI Design System v1.0, not yet applied/tested per screen

## Phase 3 — Engineering
- [ ] Validate Naho architecture
- [ ] Repository baseline
- [ ] Authentication
- [ ] Database
- [ ] Lead management
- [ ] Patient communication
- [ ] Follow-up
- [ ] Appointment logic
- [ ] AI layer
- [ ] Logging
- [ ] Deployment

## Phase 4 — Demo
- [ ] Demo clinic/data
- [ ] 5-minute demo
- [ ] ROI story
- [ ] Objection handling
- [ ] Prospect list

## Phase 5 — First Revenue
- [ ] Outreach
- [ ] Discovery
- [ ] Demo
- [ ] Pilot
- [ ] Feedback
- [ ] First paid account
- [ ] Onboarding system
