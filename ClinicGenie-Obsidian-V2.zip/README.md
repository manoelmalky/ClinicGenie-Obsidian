# ClinicGenie — Obsidian Vault

This vault is the operating system for the ClinicGenie project.

## Start here
Open `00 Command Center.md`.

## Structure
- `01 Project` — master plan and scope
- `02 Product` — vision and workflows
- `03 UI-UX` — visual truth and screens
- `04 Engineering` — technical truth
- `05 Team` — Mano/Naho workstreams
- `06 Go-To-Market` — sales
- `07 Research` — market research
- `08 Decisions` — decisions
- `09 Prompts` — reusable prompts
- `10 Meetings` — meetings
- `11 Tasks` — execution

## Source of truth
Obsidian = project/product knowledge.
GitHub = code.
Approved UI references = visual truth.
