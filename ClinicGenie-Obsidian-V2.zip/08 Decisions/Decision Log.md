# ClinicGenie — Decision Log

## Template
### YYYY-MM-DD — Decision title
**Decision:**  
**Why:**  
**Alternatives:**  
**Impact:**  
**Owner:**  
**Status:** Active / Revisit / Superseded

---

### 2026-09-12 — Obsidian becomes the project knowledge base
**Decision:** Use Obsidian as the working knowledge base for ClinicGenie planning, product documentation, decisions, prompts, research, and team coordination.
**Why:** Centralize the project so product, design, engineering, GTM, and decisions remain connected.
**Owner:** Mano
**Status:** Active

---

### 2026-09-13 — Visual system locked across six screens
**Decision:** Command Center, Leads, Lead Detail, Conversation, Appointments, and Automations are approved as the single visual source of truth. Design tokens formally extracted into `UI Design System v1.0`.
**Why:** Prevent drift as remaining screens (Patients, Reports, Settings) are designed.
**Alternatives:** Continue designing screen-by-screen without a documented token set — rejected, already caused the vault's own Screen Inventory to fall out of sync with what was actually approved.
**Impact:** Any new screen must be checked against `03 UI-UX/03 UI Design System v1.0.md` before being marked approved.
**Owner:** Mano
**Status:** Active

---

### 2026-09-13 — Lead Lifecycle and Lead Intent are separate fields
**Decision:** A lead has two independent status fields — Lifecycle (New→Contacted→Qualified→Booked→Completed/Lost) and Intent (New/Interested/High Potential/Warm/No Response/Human Needed). They are never merged into one field or one badge.
**Why:** They answer different questions (pipeline stage vs. engagement level) and both are needed to drive Genie's recommended actions correctly — e.g. "Contacted + No Response" is a real, meaningful combination.
**Alternatives:** Single status field — rejected, loses the ability to trigger follow-up automations on stalled-but-not-lost leads.
**Impact:** Data model must implement these as two columns/enums, not one. See `02 Product/03 Status Model.md`.
**Owner:** Mano
**Status:** Active — flagged as pending confirmation from Naho on data model implications
