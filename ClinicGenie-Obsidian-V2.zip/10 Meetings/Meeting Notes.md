# ClinicGenie — Meeting Notes

## Template
### YYYY-MM-DD — Meeting title
**Participants:**  
**Goal:**  

### Decisions
- 

### Discussion
- 

### Action items
- [ ] 

### Open questions
- 

### Links
- 
