# ClinicGenie — Architecture

## Technical owner
Naho

## Status
**Draft proposal, not yet confirmed by Naho.** This replaces an empty checklist with a concrete starting point sized to the stated constraint below — every line is a proposal to accept, edit, or override, not a locked decision. Once reviewed, promote confirmed choices into the Decision Log.

## Constraint (unchanged)
Prefer free tiers, open-source components, and low-cost infrastructure until validation. Architecture must serve V1. Avoid premature enterprise complexity.

## Proposed stack

| Layer | Proposal | Why | Cost at V1 |
|---|---|---|---|
| Frontend | React + Tailwind, deployed on Vercel | Matches the approved screens' component patterns (see UI Design System v1.0); Vercel free tier covers a single-clinic-scale demo | $0 |
| Backend | Node/Express or Next.js API routes (same repo as frontend if using Next.js) | Keeps one deploy target, fastest to ship V1 | $0 on Vercel free tier |
| Database | Postgres via Supabase | Free tier, built-in auth, row-level security fits multi-tenant "clinic separation" requirement directly | $0 up to free-tier limits |
| Authentication | Supabase Auth | Avoid building auth from scratch; RLS policies enforce clinic separation at the DB layer, not just app logic | $0 |
| AI provider/model | Claude API (Anthropic) | Product is already "Genie"-branded around Claude-style assistant behavior; use for classification (intent), reply drafting, and Genie Insight generation | Pay-per-use, low at demo volume |
| Messaging | Twilio (SMS) and/or WhatsApp Business API for patient conversation channel | Matches "Meta" lead source shown in screens (Facebook/Instagram lead ads feed into conversation) | Pay-per-use, low at demo volume |
| Appointment integration | Start with an internal calendar/slots model (as shown in Appointments screen); defer real EHR/PMS integration | Real dental PMS integrations (Dentrix, Open Dental, etc.) are high-effort — avoid for V1 per non-goals | $0 |
| Hosting | Vercel (frontend/API) + Supabase (DB/auth) | Both have workable free tiers | $0 |
| Secrets/environment variables | Vercel environment variables + Supabase project secrets | Standard, no extra tooling | $0 |
| Logging | Vercel/Supabase built-in logs for V1; add a dedicated tool only post-validation | Avoid premature complexity | $0 |
| Error handling | Standard try/catch + user-facing fallback messaging in Genie surfaces (e.g., "Genie couldn't complete this — take over conversation") | Matches the product's "human handoff always available" principle | — |
| Security/privacy | Supabase RLS for clinic separation; encrypt patient PII at rest (Supabase default); no PHI/HIPAA claims without dedicated review | Dental patient data is sensitive even if not strictly HIPAA-covered depending on scope — **flag for legal review before first paying clinic**, not before demo | — |
| Cost model, $0 → first customer | All of the above free-tier until real usage; first real cost driver is likely Claude API + messaging volume, both usage-based | Stays near $0 through demo phase | ~$0 through demo |

## Data model — first pass (needs Naho + Mano review)

Core entities implied by the approved screens and the new Status Model doc:
- `clinics` (tenant root — everything else scopes to `clinic_id`)
- `leads` (lifecycle, intent, treatment, source, campaign, owner [staff or Genie], created_at, last_contacted_at)
- `patients` — relationship to `leads` not yet defined (see Status Model open item: is a Patient a converted Lead, or separate?)
- `conversations` / `messages` (sender_type: patient/genie/human/system, body, timestamp, conversation_id)
- `appointments` (status, treatment, provider, patient/lead reference, booked_by: clinic/genie)
- `automations` (trigger, condition, action, schedule, stop_condition, status, run_history)
- `automation_runs` (per-execution log — needed for the "Recent Automation Activity" feed and "Needs Attention" status)
- `genie_insights` / `genie_actions` (if these should be persisted/audited rather than generated on the fly — **needs a decision**: are Genie Insights computed live per page load, or stored as records with their own lifecycle? Affects whether "Genie Insight" can be dismissed/tracked over time.)

## Architecture checklist (tracking)
- [x] Frontend — proposed (React/Next.js + Tailwind on Vercel)
- [x] Backend — proposed (Next.js API routes or Express)
- [x] Database — proposed (Supabase Postgres)
- [x] Authentication — proposed (Supabase Auth + RLS)
- [x] AI provider/model — proposed (Claude API)
- [x] Messaging — proposed (Twilio/WhatsApp Business API)
- [x] Appointment integration — proposed (internal model for V1, defer PMS integration)
- [x] Hosting — proposed (Vercel + Supabase)
- [x] Secrets/environment variables — proposed (platform-native)
- [x] Logging — proposed (platform-native for V1)
- [x] Error handling — proposed (human-handoff fallback pattern)
- [x] Security/privacy — proposed, **flagged for legal review before paid pilot**
- [x] Cost model from $0 to first customer — proposed (usage-based only past free tiers)

## Open decisions before this can move from "proposed" to "confirmed"
1. Does this match or conflict with Naho's actual architecture plan/repo audit? (This doc was written without that input — it's a placeholder proposal, not a reconciliation.)
2. Patients vs. Leads: separate table or same table with a lifecycle filter?
3. Are Genie Insights/Actions persisted records or computed on read?
4. Which Genie actions require clinic approval before executing (ties to Status Model open item)?
5. PMS/EHR integration — confirmed out of scope for V1, or needed for a specific target clinic?
