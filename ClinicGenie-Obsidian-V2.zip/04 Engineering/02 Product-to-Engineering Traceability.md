# Product → Engineering Traceability

This page connects product requirements to implementation.

## Rule
Every major feature should have:
1. Product requirement
2. UI specification, when applicable
3. Technical design
4. Task
5. GitHub issue/PR
6. Acceptance test

## Example
Lead Follow-Up
→ [[02 Product/Requirements/03 Follow-Up]]
→ [[02 Product/Workflows/03 Follow-Up Workflow]]
→ technical design
→ implementation task
→ GitHub
→ QA

## Engineering principle
Do not implement undocumented behavior that changes the product contract without recording the decision.
