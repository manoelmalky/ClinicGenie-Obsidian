# Mano — Workstream

## Role
Product vision + creative/product direction.

## Focus
- Product vision
- UX/UI
- Brand
- Dental workflows
- Sales/demo
- Customer discovery
- GTM
- Product prioritization

## Current priorities
- Finish UI system
- Define V1 behavior
- Translate dental workflow knowledge into product rules
- Prepare demo/sales system
- Keep the product buildable and simple
