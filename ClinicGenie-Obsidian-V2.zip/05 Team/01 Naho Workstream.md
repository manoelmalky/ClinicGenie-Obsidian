# Naho — Workstream

## Role
Technical owner.

## Focus
- Architecture
- Prompt engineering
- Claude Code / coding workflow
- Frontend/backend
- Integrations
- Infrastructure
- Technical QA

## Mano provides
- Product vision
- UX/UI direction
- Brand
- Dental workflow knowledge
- Sales requirements
- Priority decisions

## Current source
Paste/link Naho's latest architecture plan and repo audit here.
