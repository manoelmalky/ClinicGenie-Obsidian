# ClinicGenie — Collaboration Protocol

## Ownership

### Mano
Owns product vision, UX direction, dental workflow, GTM, customer discovery, and feature priority.

### Naho
Owns architecture, engineering, AI implementation, infrastructure, integrations, and technical QA.

### Shared
Decisions, requirements, release criteria, and major workflow changes.

## Workflow
1. Mano identifies a problem/opportunity.
2. Product requirement is documented.
3. UI specification is created when needed.
4. Naho validates technical feasibility.
5. Decision is recorded if trade-offs exist.
6. Task is created.
7. Naho implements in GitHub.
8. Result is reviewed.
9. Acceptance criteria are checked.
10. Obsidian is updated with the final decision/behavior.

## Git rule
Do not both heavily edit the same Markdown file at the same time. Prefer separate pages for separate workstreams and merge deliberate changes.

## Naming
Use clear names and stable links. Do not create duplicate pages for the same concept.
